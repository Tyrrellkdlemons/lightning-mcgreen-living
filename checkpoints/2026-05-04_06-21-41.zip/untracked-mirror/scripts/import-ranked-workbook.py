#!/usr/bin/env python3
"""
Import ranked apartment workbook rows into JSON used by the apply engine.

Usage:
  python scripts/import-ranked-workbook.py
  python scripts/import-ranked-workbook.py --input "C:\\path\\file.xlsx"
  python scripts/import-ranked-workbook.py --input "C:\\path\\file.xlsx" --output "src/lib/data/generated/workbook-ranked-listings.json"
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from openpyxl import load_workbook


def as_num(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace("$", "").replace(",", "")
    if s == "" or s.lower().startswith("verify"):
        return None
    try:
        return float(s)
    except Exception:
        return None


def as_int(v):
    n = as_num(v)
    return int(n) if n is not None else None


def as_str(v):
    if v is None:
        return None
    s = str(v).strip()
    return s if s else None


def slug(s: str):
    s = (s or "").lower()
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s[:80]


def infer_platform(url_blob: str | None, mgmt: str | None, flag: str | None):
    b = f"{url_blob or ''} {mgmt or ''} {flag or ''}".lower()
    if "appfolio" in b:
        return "AppFolio"
    if "on-site" in b or "on-site.com" in b:
        return "On-Site"
    if "rentcafe" in b:
        return "RentCafe"
    if "entrata" in b:
        return "Entrata"
    if "realpage" in b:
        return "RealPage"
    if "knock" in b or "g5" in b:
        return "G5/Knock"
    return "Other"


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input",
        default=r"C:\Users\TKDL\Downloads\socal_apartment_ranked_research_workbook_ENHANCED_LINKED.xlsx",
        help="Workbook path",
    )
    parser.add_argument(
        "--output",
        default=r"src/lib/data/generated/workbook-ranked-listings.json",
        help="Output JSON path",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    src = Path(args.input)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)

    if not src.exists():
        raise SystemExit(f"Input workbook not found: {src}")

    wb = load_workbook(src, data_only=True)
    if "Ranked Listings" not in wb.sheetnames:
        raise SystemExit('Sheet "Ranked Listings" not found in workbook.')
    ws = wb["Ranked Listings"]
    headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
    idx = {h: i for i, h in enumerate(headers)}

    rows = []
    for r in range(2, ws.max_row + 1):
        prop = as_str(ws.cell(r, idx["Property Name"] + 1).value)
        if not prop:
            continue
        city = as_str(ws.cell(r, idx["City"] + 1).value)
        county = as_str(ws.cell(r, idx["County"] + 1).value)
        rank = as_int(ws.cell(r, idx["Rank"] + 1).value)
        match_percent = as_num(ws.cell(r, idx["Match %"] + 1).value)
        rent_low = as_num(ws.cell(r, idx["Rent Low"] + 1).value)
        rent_high = as_num(ws.cell(r, idx["Rent High"] + 1).value)
        screening_difficulty = as_num(ws.cell(r, idx["Screening Difficulty"] + 1).value)

        direct_unit_link = as_str(ws.cell(r, idx["Direct Unit Link"] + 1).value)
        floor_plan_link = as_str(ws.cell(r, idx["Floor Plan Link"] + 1).value)
        leasing_site = as_str(ws.cell(r, idx["Leasing Site"] + 1).value)
        source_url = as_str(ws.cell(r, idx["Source URL"] + 1).value)
        best_listing_url = as_str(ws.cell(r, idx["Best Listing URL"] + 1).value)
        floor_plan_url = as_str(ws.cell(r, idx["Floor Plan URL"] + 1).value)
        leasing_url = as_str(ws.cell(r, idx["Leasing URL"] + 1).value)
        source_url_clickable = as_str(ws.cell(r, idx["Source URL Clickable"] + 1).value)
        mgmt = as_str(ws.cell(r, idx["Mgmt/Leasing Company"] + 1).value)
        greystar_flag = as_str(ws.cell(r, idx["Greystar/Snappt Flag"] + 1).value)

        url_blob = " ".join(
            [
                x
                for x in [
                    direct_unit_link,
                    floor_plan_link,
                    leasing_site,
                    source_url,
                    best_listing_url,
                    floor_plan_url,
                    leasing_url,
                    source_url_clickable,
                ]
                if x
            ]
        )
        platform = infer_platform(url_blob, mgmt, greystar_flag)

        rec = {
            "id": f"wb-{rank or r}-{slug(prop)}-{slug(city or county or 'ca')}",
            "rank": rank,
            "match_percent": match_percent,
            "fit_tier": as_str(ws.cell(r, idx["Fit Tier"] + 1).value),
            "property_name": prop,
            "city": city,
            "county": county,
            "priority_city_match": as_str(ws.cell(r, idx["Priority City Match"] + 1).value),
            "neighborhood": as_str(ws.cell(r, idx["Neighborhood"] + 1).value),
            "address": as_str(ws.cell(r, idx["Address"] + 1).value),
            "beds": as_str(ws.cell(r, idx["Beds"] + 1).value),
            "baths": as_str(ws.cell(r, idx["Baths"] + 1).value),
            "sqft_range": as_str(ws.cell(r, idx["Sq Ft / Range"] + 1).value),
            "rent_low": rent_low,
            "rent_high": rent_high,
            "unit_or_floor": as_str(ws.cell(r, idx["Unit # / Floor #"] + 1).value),
            "floor_plan": as_str(ws.cell(r, idx["Floor Plan"] + 1).value),
            "availability": as_str(ws.cell(r, idx["Availability"] + 1).value),
            "screening_vendor": as_str(ws.cell(r, idx["Screening Vendor"] + 1).value),
            "screening_difficulty": screening_difficulty,
            "screening_difficulty_label": as_str(ws.cell(r, idx["Screening Difficulty Label"] + 1).value),
            "greystar_snappt_flag": greystar_flag,
            "action_status": as_str(ws.cell(r, idx["Action Status"] + 1).value),
            "score_notes": as_str(ws.cell(r, idx["Score Notes"] + 1).value),
            "best_feature": as_str(ws.cell(r, idx["Best Feature"] + 1).value),
            "missing_preferences": as_str(ws.cell(r, idx["Missing Preferences"] + 1).value),
            "questions_to_ask_leasing": as_str(ws.cell(r, idx["Questions To Ask Leasing"] + 1).value),
            "source_date": as_str(ws.cell(r, idx["Source Date"] + 1).value),
            "application_platform_inferred": platform,
            "links": {
                "direct_unit_link": direct_unit_link,
                "floor_plan_link": floor_plan_link,
                "leasing_site": leasing_site,
                "source_url": source_url,
                "best_listing_url": best_listing_url,
                "floor_plan_url": floor_plan_url,
                "leasing_url": leasing_url,
                "source_url_clickable": source_url_clickable,
            },
        }
        rows.append(rec)

    rows.sort(key=lambda x: (x["rank"] is None, x["rank"] or 9999, x["property_name"]))
    out.write_text(json.dumps(rows, indent=2), encoding="utf-8")
    print(f"Wrote {len(rows)} rows to {out}")


if __name__ == "__main__":
    main()
