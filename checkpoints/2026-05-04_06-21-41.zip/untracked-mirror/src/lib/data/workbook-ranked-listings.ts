import raw from './generated/workbook-ranked-listings.json';

export interface WorkbookLinks {
  direct_unit_link?: string | null;
  floor_plan_link?: string | null;
  leasing_site?: string | null;
  source_url?: string | null;
  best_listing_url?: string | null;
  floor_plan_url?: string | null;
  leasing_url?: string | null;
  source_url_clickable?: string | null;
}

export interface WorkbookRankedListing {
  id: string;
  rank?: number | null;
  match_percent?: number | null;
  fit_tier?: string | null;
  property_name: string;
  city?: string | null;
  county?: string | null;
  priority_city_match?: string | null;
  neighborhood?: string | null;
  address?: string | null;
  beds?: string | null;
  baths?: string | null;
  sqft_range?: string | null;
  rent_low?: number | null;
  rent_high?: number | null;
  unit_or_floor?: string | null;
  floor_plan?: string | null;
  availability?: string | null;
  screening_vendor?: string | null;
  screening_difficulty?: number | null;
  screening_difficulty_label?: string | null;
  greystar_snappt_flag?: string | null;
  action_status?: string | null;
  score_notes?: string | null;
  best_feature?: string | null;
  missing_preferences?: string | null;
  questions_to_ask_leasing?: string | null;
  source_date?: string | null;
  application_platform_inferred?: string | null;
  links: WorkbookLinks;
}

export const WORKBOOK_RANKED_LISTINGS = raw as WorkbookRankedListing[];

export const WORKBOOK_CITY_OPTIONS = Array.from(
  new Set(WORKBOOK_RANKED_LISTINGS.map((x) => x.city).filter(Boolean) as string[]),
).sort();

export function workbookPrimaryUrl(x: WorkbookRankedListing): string | null {
  return (
    x.links.best_listing_url ??
    x.links.leasing_url ??
    x.links.source_url_clickable ??
    x.links.source_url ??
    x.links.leasing_site ??
    null
  );
}
